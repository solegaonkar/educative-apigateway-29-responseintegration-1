exports.handler = async (event, context) => {
  return 1 / 0;
};
